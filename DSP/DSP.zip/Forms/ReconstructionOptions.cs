﻿using DSP.Signals;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DSP
{
    public partial class ReconstructionOptions : Form
    {
        private Signal basicSignal;
        private Signal sampledSignal;
        private Signal quantizedSignal;

        private Action<Signal> callback;

        public ReconstructionOptions(Signal basicSignal, Signal signal,
            Signal quantizedSignal, Action<Signal> callback)
        {
            
            InitializeComponent();

            this.sampledSignal = signal;
            this.quantizedSignal = quantizedSignal;
            this.basicSignal = basicSignal;

            this.callback = callback;

            comboBoxSignalToReconstruct.Items.Add("Sygnał spróbkowany");

            if (quantizedSignal != null)
            {
                comboBoxSignalToReconstruct.Items.Add("Sygnał skwantowany");
            }
        }

        private void buttonRecontruction_Click(object sender, EventArgs e)
        {
            ReconstructedSignal reconstructedSignal = null;
            switch (comboBoxSignalToReconstruct.SelectedIndex)
            {
                case 1:

                    reconstructedSignal = new ReconstructedSignal(quantizedSignal.A, quantizedSignal.t1, quantizedSignal.d,
                quantizedSignal.T, quantizedSignal.isContinuous, comboBoxReconstructionType.SelectedIndex,
                sampledSignal.sampleFrequency, quantizedSignal.f, quantizedSignal.PointsReal, basicSignal.PointsReal, null, 
                comboBoxReconstructionType.SelectedIndex == 0 ? 0 : int.Parse(maskedTextBoxNumberOfSamplesSinc.Text));

                    

                    break;

                case 0:

                    reconstructedSignal = new ReconstructedSignal(sampledSignal.A, sampledSignal.t1, sampledSignal.d,
                sampledSignal.T, sampledSignal.isContinuous, comboBoxReconstructionType.SelectedIndex,
                sampledSignal.sampleFrequency, sampledSignal.f, sampledSignal.PointsReal, basicSignal.PointsReal, null,
                comboBoxReconstructionType.SelectedIndex == 0 ? 0 : int.Parse(maskedTextBoxNumberOfSamplesSinc.Text));

                    

                    break;
            }

            if (reconstructedSignal != null)
            {
                callback(reconstructedSignal);
                Close();
            }
        }
    }
}
